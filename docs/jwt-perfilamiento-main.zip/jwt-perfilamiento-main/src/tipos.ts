/** Atribución ya apareada: nodo del árbol funcional y letras RWXD otorgadas sobre él. */
export interface Atribucion {
  path: string
  propiedad: string
}

/** Alcance crudo tal como viene en el token, pareado con su template. */
export interface Alcance {
  path: string
  templatePath: string
}

export type TipoProblema =
  | 'desborde_puntos'
  | 'alcance_corto'
  | 'etiqueta_repetida'
  | 'sucursal_fantasma'

export interface Problema {
  tipo: TipoProblema
  detalle: string
}

export interface EmpresaSesion {
  key: string
  rut: string
  nombre: string
}

export interface SesionPerfilamiento {
  jti: string
  expiresAt: Date
  /** Empresa escalar del token (un token = una empresa). null si no hay alcance Empresa usable. */
  empresa: EmpresaSesion | null
  /** Alcances distintos del de Empresa, crudos {path, templatePath}. */
  alcances: Alcance[]
  atribuciones: Atribucion[]
  problemas: Problema[]
  reentryUrl: string | null
  jwt: string
}

export type Rechazo =
  | { status: 401; tipo: 'token_malformado' | 'alg_invalido' | 'firma_invalida' | 'iss_invalido' }
  | { status: 401; tipo: 'expirado'; reentryUrl: string | null }
  | { status: 403; tipo: 'sin_atribucion_ftg' | 'sin_empresa' | 'sucursal_con_desborde' }
  | { status: 503; tipo: 'clave_publica_invalida' }

export type ResultadoSesion = { ok: true; sesion: SesionPerfilamiento } | { ok: false; rechazo: Rechazo }

export interface OpcionesVerificar {
  /** Reloj inyectable para tests. Default: new Date(). */
  ahora?: Date
  /** Tolerancia simétrica sobre nbf y exp, en segundos. Default: 300 (±5 minutos). */
  toleranciaSegundos?: number
  /** Path raíz del árbol de atribuciones. Default: '.Ftg.'. */
  raizAtribuciones?: string
}

export interface ResultadoParseoAlcances {
  alcances: Alcance[]
  empresa: EmpresaSesion | null
  problemas: Problema[]
  sinEmpresa: boolean
  sucursalConDesborde: boolean
}
