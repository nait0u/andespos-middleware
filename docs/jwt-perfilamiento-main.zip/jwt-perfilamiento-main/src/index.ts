export type {
  Alcance,
  Atribucion,
  EmpresaSesion,
  OpcionesVerificar,
  Problema,
  Rechazo,
  ResultadoParseoAlcances,
  ResultadoSesion,
  SesionPerfilamiento,
  TipoProblema,
} from './tipos.js'
export { verificarToken } from './verificar.js'
export { tieneAccesoFtg, puedeRealizar } from './atribuciones.js'
export { parsearAlcances } from './alcances.js'
