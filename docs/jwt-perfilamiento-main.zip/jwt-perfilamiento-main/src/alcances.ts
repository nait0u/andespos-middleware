import type { Alcance, EmpresaSesion, Problema, ResultadoParseoAlcances } from './tipos.js'

/**
 * Segmentos de un path/template delimitado por puntos: se descartan solo los
 * vacíos de los bordes; los vacíos o espacios intermedios son datos reales
 * (p. ej. la sucursal fantasma viene como segmentos de un espacio).
 */
function segmentos(s: string): string[] {
  const partes = s.split('.')
  return partes.filter((seg, i) => !(seg === '' && (i === 0 || i === partes.length - 1)))
}

/**
 * Alinea valores del path contra etiquetas del template, anclado a la
 * izquierda. Si hay más valores que etiquetas (nombre de empresa con puntos,
 * p. ej. "ACEROS AZA S.A."), la última etiqueta absorbe los segmentos
 * sobrantes (tail greedy) reconstruyendo el valor con sus puntos.
 */
function alinear(etiquetas: string[], valores: string[]): Map<string, string> {
  const mapa = new Map<string, string>()
  if (valores.length > etiquetas.length && etiquetas.length > 0) {
    const ultima = etiquetas[etiquetas.length - 1]!
    for (let i = 0; i < etiquetas.length - 1; i++) mapa.set(etiquetas[i]!, valores[i] ?? '')
    mapa.set(ultima, valores.slice(etiquetas.length - 1).join('.'))
  } else {
    for (let i = 0; i < etiquetas.length; i++) mapa.set(etiquetas[i]!, valores[i] ?? '')
  }
  return mapa
}

function etiquetasRepetidas(etiquetas: string[]): string[] {
  const vistas = new Set<string>()
  const repetidas = new Set<string>()
  for (const e of etiquetas) {
    if (vistas.has(e)) repetidas.add(e)
    vistas.add(e)
  }
  return [...repetidas]
}

/**
 * Parsea el claim Rol.Alcance del token. Cada ítem trae AlcancePath con los
 * valores y AlcanceTemplatePath con las etiquetas; se alinean anclados a la
 * izquierda con tail greedy en la última etiqueta.
 *
 * Hechos de negocio que maneja:
 * - Un token = una empresa: se extrae del alcance con raíz '*Empresa' como
 *   escalar; los demás alcances se devuelven crudos en la colección.
 * - Centinela sin empresa (EmpKey = '0'): forma esperada, flag sinEmpresa.
 * - Nombre con puntos sin sucursal: degrada con 'desborde_puntos'.
 * - Nombre con puntos CON sucursal en el template: no se puede alinear la
 *   sucursal (el desborde corre todo lo que sigue) → flag sucursalConDesborde.
 * - Sucursal fantasma (segmentos de un espacio): degrada con 'sucursal_fantasma'.
 * - Menos valores que etiquetas: degrada con 'alcance_corto'.
 * - Etiqueta repetida en el template: degrada con 'etiqueta_repetida'.
 *
 * Entrada tolerante: raw que no sea array de {AlcancePath, AlcanceTemplatePath}
 * string se trata como conjunto vacío.
 */
export function parsearAlcances(raw: unknown): ResultadoParseoAlcances {
  const resultado: ResultadoParseoAlcances = {
    alcances: [],
    empresa: null,
    problemas: [],
    sinEmpresa: false,
    sucursalConDesborde: false,
  }
  if (!Array.isArray(raw)) return resultado

  for (const item of raw) {
    if (typeof item !== 'object' || item === null) continue
    const { AlcancePath, AlcanceTemplatePath } = item as Record<string, unknown>
    if (typeof AlcancePath !== 'string' || typeof AlcanceTemplatePath !== 'string') continue

    const crudo: Alcance = { path: AlcancePath, templatePath: AlcanceTemplatePath }
    const valores = segmentos(AlcancePath)
    const etiquetas = segmentos(AlcanceTemplatePath)
    const esEmpresa = valores[0] === '*Empresa' || etiquetas[0] === '*Empresa'
    const tieneSucursal = etiquetas.includes('SucursalIdL')
    const detalleBase = `alcance '${AlcancePath}' vs template '${AlcanceTemplatePath}'`

    // Centinela sin empresa: el emisor estampa EmpKey = '0' cuando el agente
    // no tiene empresa asignada. Es una forma esperada, no un desperfecto.
    if (esEmpresa && valores[1] === '0') {
      resultado.sinEmpresa = true
      continue
    }

    const repetidas = etiquetasRepetidas(etiquetas)
    if (repetidas.length > 0) {
      resultado.problemas.push({
        tipo: 'etiqueta_repetida',
        detalle: `etiqueta(s) repetida(s) ${repetidas.join(', ')} en ${detalleBase}`,
      })
    }

    let problemaAlineacion: Problema | null = null
    if (valores.length > etiquetas.length) {
      problemaAlineacion = {
        tipo: 'desborde_puntos',
        detalle: `${valores.length - etiquetas.length} segmento(s) de más (valor con puntos) en ${detalleBase}`,
      }
      // Con sucursal en el template, el desborde corre la alineación de todo
      // lo que sigue al nombre: no hay forma de recuperar la sucursal.
      if (tieneSucursal) resultado.sucursalConDesborde = true
    } else if (valores.length < etiquetas.length) {
      problemaAlineacion = {
        tipo: 'alcance_corto',
        detalle: `${etiquetas.length - valores.length} valor(es) de menos en ${detalleBase}`,
      }
    }
    if (problemaAlineacion) resultado.problemas.push(problemaAlineacion)

    const mapa = alinear(etiquetas, valores)

    // Sucursal fantasma: el emisor anexa ' . .' cuando no encuentra la sucursal.
    if (tieneSucursal && !resultado.sucursalConDesborde) {
      const sucursalFantasma = ['SucursalIdL', 'SucursalNombre'].some((e) => {
        const v = mapa.get(e)
        return v !== undefined && v.trim() === ''
      })
      if (sucursalFantasma) {
        resultado.problemas.push({
          tipo: 'sucursal_fantasma',
          detalle: `sucursal sin datos (segmentos en blanco) en ${detalleBase}`,
        })
      }
    }

    if (esEmpresa) {
      const key = mapa.get('EmpresaKey')
      const rut = mapa.get('EmpresaRut')
      const nombre = mapa.get('EmpresaNombre')
      // Si el alcance Empresa vino corto, las etiquetas pueden quedar vacías:
      // sin las tres piezas no hay empresa confiable.
      if (key && rut && nombre) {
        const empresa: EmpresaSesion = { key, rut, nombre }
        if (resultado.empresa === null) resultado.empresa = empresa
      }
    } else {
      resultado.alcances.push(crudo)
    }
  }

  return resultado
}
