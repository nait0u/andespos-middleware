import { decodeJwt, errors, importSPKI, jwtVerify } from 'jose'
import { parsearAlcances } from './alcances.js'
import { tieneAccesoFtg } from './atribuciones.js'
import type {
  Atribucion,
  OpcionesVerificar,
  Rechazo,
  ResultadoSesion,
} from './tipos.js'

const ISSUER_NOMBRE_ESPERADO = 'LanzaderaPerfilamientoEnternet'
const TOLERANCIA_DEFAULT_SEG = 300 // ±5 minutos simétricos (el dato real consume 3m20s)

function fallo(rechazo: Rechazo): ResultadoSesion {
  return { ok: false, rechazo }
}

function issValido(iss: unknown): boolean {
  // El iss NO es un string plano: es un JSON serializado (JWT_Issuer.ToJson()).
  // Se pinea solo el campo Nombre; campos extra se ignoran a propósito.
  return objetoDeClaim(iss)?.['Nombre'] === ISSUER_NOMBRE_ESPERADO
}

/**
 * Los claims compuestos de Perfilamiento (`Rol`, `iss`, `aud`) viajan como JSON
 * serializado, no como objeto JSON anidado — es un `.ToJson()` del lado GeneXus.
 * Se acepta también la forma objeto: algunos emisores podrían anidar de verdad,
 * y un cast a ciegas deja el claim en `undefined` sin ruido (era el bug que
 * hacía rechazar con `sin_atribucion_ftg` tokens que sí traían `.Ftg.`).
 */
function objetoDeClaim(valor: unknown): Record<string, unknown> | undefined {
  if (typeof valor === 'string') {
    try {
      const parsed: unknown = JSON.parse(valor)
      return typeof parsed === 'object' && parsed !== null
        ? (parsed as Record<string, unknown>)
        : undefined
    } catch {
      return undefined
    }
  }
  if (typeof valor === 'object' && valor !== null) {
    return valor as Record<string, unknown>
  }
  return undefined
}

function parsearAtribuciones(raw: unknown): Atribucion[] {
  // El token trae objetos ya apareados {AtribucionPath, Propiedad}
  // (los strings con '|' eran artefacto de PrfJWT2SDT, que no se llama).
  if (!Array.isArray(raw)) return []
  const resultado: Atribucion[] = []
  for (const item of raw) {
    if (typeof item !== 'object' || item === null) continue
    const { AtribucionPath, Propiedad } = item as Record<string, unknown>
    if (typeof AtribucionPath === 'string' && typeof Propiedad === 'string') {
      resultado.push({ path: AtribucionPath, propiedad: Propiedad })
    }
  }
  return resultado
}

/**
 * Verifica un JWT de Perfilamiento y lo traduce a sesión: firma RS256 con la
 * clave pública (la frontera de seguridad es la clave, no los claims), alg
 * pineado a RS256, iss pineado por su campo Nombre, nbf/exp con tolerancia
 * simétrica (iat se ignora: viene con el offset UTC-4 estampado como UTC).
 *
 * La clave pública llega como PEM string; bajarla y cachearla es plomería de
 * la app consumidora, no de este core.
 */
export async function verificarToken(
  jwt: string,
  clavePublicaPem: string,
  opciones: OpcionesVerificar = {},
): Promise<ResultadoSesion> {
  const toleranciaSegundos = opciones.toleranciaSegundos ?? TOLERANCIA_DEFAULT_SEG

  let clave: Awaited<ReturnType<typeof importSPKI>>
  try {
    clave = await importSPKI(clavePublicaPem, 'RS256')
  } catch {
    return fallo({ status: 503, tipo: 'clave_publica_invalida' })
  }

  let payload: Record<string, unknown>
  try {
    const { payload: p } = await jwtVerify(jwt, clave, {
      // alg pineado a RS256: nunca se lee del header para decidir.
      algorithms: ['RS256'],
      clockTolerance: toleranciaSegundos,
      ...(opciones.ahora ? { currentDate: opciones.ahora } : {}),
      // aud NO se pinea (no es una audiencia: trae al portador).
      // issuer NO se pasa: igualdad de string acoplada al ToJson() de GeneXus;
      // el pineo es por el campo Nombre del JSON, más abajo.
    })
    payload = p as Record<string, unknown>
  } catch (e) {
    const code = (e as { code?: string }).code
    if (
      code === 'ERR_JWT_EXPIRED' ||
      (e instanceof errors.JWTClaimValidationFailed &&
        (e as { claim?: string }).claim === 'nbf')
    ) {
      // Expirado o aún no vigente: el browser vuelve a la lanzadera a re-elegir.
      let reentryUrl: string | null = null
      try {
        const crudo = decodeJwt(jwt) as Record<string, unknown>
        if (typeof crudo['ReentryURL'] === 'string') reentryUrl = crudo['ReentryURL']
      } catch {
        // sin ReentryURL legible → null
      }
      return fallo({ status: 401, tipo: 'expirado', reentryUrl })
    }
    if (code === 'ERR_JWS_SIGNATURE_VERIFICATION_FAILED') {
      return fallo({ status: 401, tipo: 'firma_invalida' })
    }
    if (code === 'ERR_JWS_INVALID' || code === 'ERR_JWT_MALFORMED') {
      return fallo({ status: 401, tipo: 'token_malformado' })
    }
    // Header con alg distinto: jose lo rechaza contra algorithms=['RS256'].
    if (code === 'ERR_JOSE_ALG_NOT_ALLOWED' || code === 'ERR_JOSE_NOT_SUPPORTED') {
      return fallo({ status: 401, tipo: 'alg_invalido' })
    }
    return fallo({ status: 401, tipo: 'token_malformado' })
  }

  if (!issValido(payload['iss'])) {
    return fallo({ status: 401, tipo: 'iss_invalido' })
  }

  const jti = payload['jti']
  const exp = payload['exp']
  if (typeof jti !== 'string' || typeof exp !== 'number') {
    return fallo({ status: 401, tipo: 'token_malformado' })
  }

  const rol = objetoDeClaim(payload['Rol'])
  const atribuciones = parsearAtribuciones(rol?.['Atribucion'])
  const alcancesParseados = parsearAlcances(rol?.['Alcance'])

  // Puerta gruesa: sin atribución bajo la raíz, no hay sesión.
  if (!tieneAccesoFtg(atribuciones, opciones.raizAtribuciones)) {
    return fallo({ status: 403, tipo: 'sin_atribucion_ftg' })
  }
  // Conjunto vacío ≠ parámetro ausente: el centinela no entra.
  if (alcancesParseados.sinEmpresa) {
    return fallo({ status: 403, tipo: 'sin_empresa' })
  }
  // Con sucursal en el template, un nombre con puntos corre toda la alineación.
  if (alcancesParseados.sucursalConDesborde) {
    return fallo({ status: 403, tipo: 'sucursal_con_desborde' })
  }

  return {
    ok: true,
    sesion: {
      jti,
      expiresAt: new Date(exp * 1000),
      empresa: alcancesParseados.empresa,
      alcances: alcancesParseados.alcances,
      atribuciones,
      problemas: alcancesParseados.problemas,
      reentryUrl:
        typeof payload['ReentryURL'] === 'string' ? payload['ReentryURL'] : null,
      jwt,
    },
  }
}
