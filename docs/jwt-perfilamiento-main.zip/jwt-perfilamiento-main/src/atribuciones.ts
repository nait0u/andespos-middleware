import type { Atribucion } from './tipos.js'

const RAIZ_DEFAULT = '.Ftg.'

/**
 * Normaliza un path de atribución para comparaciones segmento-seguras:
 * garantiza punto inicial y final, de modo que `startsWith` corte siempre
 * en límite de segmento ('.Ftg.' no es prefijo de '.Ftg2.').
 */
function normalizarPath(path: string): string {
  let p = path
  if (!p.startsWith('.')) p = '.' + p
  if (!p.endsWith('.')) p = p + '.'
  return p
}

/**
 * Match de letra por contención delimitada: la propiedad real viene como
 * '.X.C.R.U.D.', así que la letra debe aparecer rodeada de puntos.
 * Una propiedad 'XCRUD' sin delimitadores NO otorga nada.
 */
function propiedadOtorga(propiedad: string, letra: string): boolean {
  let p = propiedad
  if (!p.startsWith('.')) p = '.' + p
  if (!p.endsWith('.')) p = p + '.'
  return p.includes('.' + letra + '.')
}

type TipoMatch = 'exacto' | 'arbol' | 'rama'

function matchPath(atrPath: string, path: string, tipo: TipoMatch): boolean {
  switch (tipo) {
    case 'exacto':
      return atrPath === path
    case 'arbol':
      // La atribución cubre su propio path y sus descendientes.
      return path.startsWith(atrPath)
    case 'rama':
      // Solo para R: una atribución en un nodo descendiente otorga lectura
      // de sus ancestros ("para llegar hasta ella").
      return atrPath.startsWith(path) && atrPath !== path
  }
}

/**
 * Puerta gruesa: hay acceso si existe al menos una atribución cuyo path
 * sea la raíz o esté bajo la raíz. Acredita pertenencia, no autoridad.
 */
export function tieneAccesoFtg(atribuciones: Atribucion[], raiz: string = RAIZ_DEFAULT): boolean {
  const r = normalizarPath(raiz)
  return atribuciones.some((a) => {
    const p = normalizarPath(a.path)
    return p === r || p.startsWith(r)
  })
}

/**
 * Evalúa si las atribuciones otorgan TODAS las letras pedidas sobre `path`
 * (AND entre letras; cada letra puede venir de una atribución distinta).
 *
 * Reglas de negocio:
 * - Las letras R/C/U/D/X son independientes entre sí.
 * - R acepta match exacto, árbol y rama. C/U/D/X solo exacto o árbol.
 * - "La raíz da entrada, no autoridad": una atribución en la raíz pelada
 *   queda excluida del match árbol para descendientes (solo cuenta exacto).
 */
export function puedeRealizar(
  atribuciones: Atribucion[],
  path: string,
  letras: string,
  raiz: string = RAIZ_DEFAULT,
): boolean {
  const p = normalizarPath(path)
  const r = normalizarPath(raiz)

  return [...letras].every((letra) =>
    atribuciones.some((a) => {
      if (!propiedadOtorga(a.propiedad, letra)) return false
      const ap = normalizarPath(a.path)
      const esRaizPelada = ap === r
      if (matchPath(ap, p, 'exacto')) return true
      // La raíz pelada no concede ningún nodo hijo.
      if (esRaizPelada) return false
      if (matchPath(ap, p, 'arbol')) return true
      // El match rama es exclusivo de R.
      return letra === 'R' && matchPath(ap, p, 'rama')
    }),
  )
}
