# Compartir este módulo con otro dev

Checklist para dar acceso a `@andestec/jwt-perfilamiento` a un nuevo colaborador.

## Bloqueante (sin esto no le funciona)

- [x] Mergear `fix/rol-claim-json-string` a `main` (hecho — `main` está en `v0.1.2`, commit `3455138`).
- [ ] Invitar al colaborador como **Collaborator (Write)** en el repo de GitHub.
- [ ] El colaborador debe tener su propia clave SSH registrada en su cuenta de GitHub (el `README.md` instala vía `git+ssh`).
- [ ] El colaborador debe correr `pnpm approve-builds` en su proyecto consumidor (o ya viene aprobado si clona el mismo `pnpm-workspace.yaml`) para que el lifecycle `prepare` (que corre `tsc` y genera `dist/`) se ejecute al instalar desde git.

## Recomendado (evita fricción, no bloquea)

- [ ] Fijar en el `README.md` qué tag instalar (ej. `v0.1.2`) en lugar de apuntar a `main` a secas, para no romperle el build si se sigue pusheando.
- [ ] Agregar un `CONTRIBUTING.md` corto: cómo levantar el proyecto, correr tests (`vitest`), buildear (`pnpm build`) y taguear una versión nueva.
- [ ] Definir una licencia real (aunque sea "uso interno") — hoy el `package.json` marca `UNLICENSED` y es `private: true`.

## Contexto (estado del repo al momento de este checklist)

- Paquete: `@andestec/jwt-perfilamiento@0.1.2`, ESM, `private: true`, `license: UNLICENSED`.
- Instalación: vía `git+ssh`, sin publicar a un registry npm.
- `dist/` está en `.gitignore` — se genera al instalar gracias al script `prepare` (`tsc -p tsconfig.build.json`).
- Tests: `vitest`, 3 archivos en `test/`.
- No hay CI (`.github/workflows`) ni `LICENSE` ni `CONTRIBUTING.md`.
- Tags existentes: `v0.1.0`, `v0.1.1`, `v0.1.2`.
