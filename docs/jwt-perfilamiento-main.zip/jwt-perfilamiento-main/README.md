# @andestec/jwt-perfilamiento

Core puro de TypeScript para recibir sesiones de **Perfilamiento** (Enternet/GeneXus):
verifica el JWT RS256 que postea la lanzadera y lo traduce a una sesión tipada
(empresa, alcances, atribuciones RWXD, problemas de parseo degradado).

**Sin NestJS, sin persistencia, sin HTTP.** La app consumidora baja y cachea la
clave pública (`PublicKeyPrfURL`), persiste la sesión y monta el guard; este
paquete es el seam puro: verify + parse + match.

## Instalación

Dependencia git de pnpm, por tag (repo privado, requiere deploy key SSH):

```bash
pnpm add git+ssh://git@github.com/matop/jwt-perfilamiento.git#v0.1.0
```

## Uso

```ts
import { verificarToken, puedeRealizar } from '@andestec/jwt-perfilamiento'

const resultado = await verificarToken(jwt, clavePublicaPem)
if (!resultado.ok) {
  // resultado.rechazo: ver tabla abajo
} else {
  const { jti, expiresAt, empresa, alcances, atribuciones, problemas } = resultado.sesion
}

// Control fino por nodo/letra (RWXD), para el guard de la app:
puedeRealizar(atribuciones, '.Ftg.FtgOpe.', 'R') // AND entre letras
```

## Tabla de rechazos

| status | tipo | causa |
|---|---|---|
| 401 | `token_malformado` | no es un JWT compacto / payload inválido |
| 401 | `alg_invalido` | `alg` ≠ RS256 (pineado, no leído del header) |
| 401 | `firma_invalida` | la firma no verifica con la clave dada |
| 401 | `iss_invalido` | `iss` no parsea como JSON o `Nombre` ≠ `LanzaderaPerfilamientoEnternet` |
| 401 | `expirado` | `nbf`/`exp` fuera de tolerancia (±5 min default) — trae `reentryUrl` para el redirect |
| 403 | `sin_atribucion_ftg` | sin atribución bajo la raíz (puerta gruesa) |
| 403 | `sin_empresa` | token centinela (`EmpKey = 0`) |
| 403 | `sucursal_con_desborde` | sucursal en template + nombre de empresa con puntos |
| 503 | `clave_publica_invalida` | el PEM no es importable (que falte la clave nunca saltea verificación) |

## Hechos del emisor que este core codifica

- `iss` es un **JSON serializado** (`{"Nombre":"LanzaderaPerfilamientoEnternet"}`), no un string.
- `aud` **no es audiencia** (trae al portador): no se pinea.
- `iat` es inservible (offset UTC−4 estampado como UTC): se ignora. `exp = nbf + 24h`.
- Alcances delimitados por puntos sin escape: parseo anclado a la izquierda con
  **tail greedy** en la última etiqueta (recupera nombres con puntos como
  `"ACME S.A."`). Las trampas reales degradan con `problemas[]` en vez de
  truncar en silencio.
- Letras R/C/U/D/X **independientes**; `R` es la única con match `rama` (una hija
  con permiso otorga lectura de sus ancestros); acción con varias letras = AND;
  **la raíz da entrada, no autoridad** (`.Ftg.` pelada no concede nodos hijos).

## Desarrollo

```bash
pnpm install
pnpm test        # vitest
pnpm typecheck
pnpm build       # tsc → dist/ (corre solo al instalar como dependencia git)
```
