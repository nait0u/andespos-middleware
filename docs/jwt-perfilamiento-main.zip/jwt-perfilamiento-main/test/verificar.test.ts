import { describe, it, expect, beforeAll } from 'vitest'
import { generateKeyPair, exportSPKI, SignJWT } from 'jose'
import { verificarToken } from '../src/verificar.js'

// Reloj fijo: los bordes de tolerancia se prueban contra `ahora` inyectado.
const AHORA = new Date('2026-08-01T12:00:00Z')
const epoch = (d: Date) => Math.floor(d.getTime() / 1000)
const min = 60

// Forma real documentada (handoff 2026-07-31 §11.2): nombre con puntos
// "ACEROS AZA S.A.", raíz '.*Empresa.' con asterisco, atribución '.Ftg.' pelada.
function rolBase(): Record<string, unknown> {
  return {
    Atribucion: [{ AtribucionPath: '.Ftg.', Propiedad: '.X.C.R.U.D.' }],
    Alcance: [
      {
        AlcancePath: '.*Empresa.977.921760000.ACEROS AZA S.A..',
        AlcanceTemplatePath: '.*Empresa.EmpresaKey.EmpresaRut.EmpresaNombre.',
      },
    ],
  }
}

// `Rol` viaja SERIALIZADO, igual que `iss`/`aud` — verificado contra un token
// real de la lanzadera (perfil AdminGuias, 2026-08-03). Los fixtures lo pasaban
// como objeto anidado y por eso la suite no vio el bug de `sin_atribucion_ftg`.
function payloadBase(): Record<string, unknown> {
  return {
    iss: JSON.stringify({ Nombre: 'LanzaderaPerfilamientoEnternet' }),
    aud: 'portador-redactado',
    jti: '93-1-42',
    ReentryURL: 'https://lanzadera.example/reentry',
    Rol: JSON.stringify(rolBase()),
  }
}

interface OpcionesFirma {
  nbfOffsetSeg?: number
  expOffsetSeg?: number
  iatOffsetSeg?: number
  alg?: 'RS256' | 'HS256'
}

async function firmar(
  payload: Record<string, unknown>,
  key: unknown,
  opts: OpcionesFirma = {},
): Promise<string> {
  const nbf = epoch(AHORA) + (opts.nbfOffsetSeg ?? -min)
  const jwt = new SignJWT(payload)
    .setProtectedHeader({ alg: opts.alg ?? 'RS256' })
    .setNotBefore(nbf)
    .setExpirationTime(opts.expOffsetSeg !== undefined ? epoch(AHORA) + opts.expOffsetSeg : nbf + 24 * 3600)
    // iat desfasado 4h (offset UTC-4 estampado como UTC): se ignora.
    .setIssuedAt(epoch(AHORA) + (opts.iatOffsetSeg ?? -4 * 3600 - 2 * min))
  if (opts.alg === 'HS256') {
    return jwt.sign(new TextEncoder().encode('secreto-de-test-hs256'.repeat(2)))
  }
  return jwt.sign(key as Parameters<typeof jwt.sign>[0])
}

describe('verificarToken', () => {
  let pem: string
  let privada: unknown
  let privadaOtra: unknown

  beforeAll(async () => {
    const par = await generateKeyPair('RS256')
    privada = par.privateKey
    pem = await exportSPKI(par.publicKey)
    privadaOtra = (await generateKeyPair('RS256')).privateKey
  })

  it('token válido con la forma real → sesión completa parseada', async () => {
    const jwt = await firmar(payloadBase(), privada)
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    if (!r.ok) throw new Error(`esperaba ok, vino ${JSON.stringify(r.rechazo)}`)

    expect(r.sesion.jti).toBe('93-1-42')
    // expires_at = exp del JWT verbatim.
    expect(r.sesion.expiresAt.getTime()).toBe((epoch(AHORA) - min + 24 * 3600) * 1000)
    // Tail greedy: nombre con puntos recuperado intacto, key/rut en su lugar.
    expect(r.sesion.empresa).toEqual({ key: '977', rut: '921760000', nombre: 'ACEROS AZA S.A.' })
    expect(r.sesion.atribuciones).toEqual([{ path: '.Ftg.', propiedad: '.X.C.R.U.D.' }])
    expect(r.sesion.problemas.map((p) => p.tipo)).toContain('desborde_puntos')
    expect(r.sesion.reentryUrl).toBe('https://lanzadera.example/reentry')
    expect(r.sesion.jwt).toBe(jwt)
  })

  it('alg distinto de RS256 → alg_invalido (pineado, no leído del header)', async () => {
    const jwt = await firmar(payloadBase(), privada, { alg: 'HS256' })
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r).toEqual({ ok: false, rechazo: { status: 401, tipo: 'alg_invalido' } })
  })

  it('firma con otra clave → firma_invalida', async () => {
    const jwt = await firmar(payloadBase(), privadaOtra)
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r).toEqual({ ok: false, rechazo: { status: 401, tipo: 'firma_invalida' } })
  })

  it('iss JSON con campos extra → se ignoran, token válido', async () => {
    const payload = payloadBase()
    payload['iss'] = JSON.stringify({ Nombre: 'LanzaderaPerfilamientoEnternet', Version: 3, Otro: { anidado: true } })
    const jwt = await firmar(payload, privada)
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r.ok).toBe(true)
  })

  it('iss como string plano → iss_invalido', async () => {
    const payload = payloadBase()
    payload['iss'] = 'LanzaderaPerfilamientoEnternet'
    const jwt = await firmar(payload, privada)
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r).toEqual({ ok: false, rechazo: { status: 401, tipo: 'iss_invalido' } })
  })

  it('iss.Nombre distinto → iss_invalido', async () => {
    const payload = payloadBase()
    payload['iss'] = JSON.stringify({ Nombre: 'OtraLanzadera' })
    const jwt = await firmar(payload, privada)
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r).toEqual({ ok: false, rechazo: { status: 401, tipo: 'iss_invalido' } })
  })

  it('token basura → token_malformado', async () => {
    expect(await verificarToken('no-es-un-jwt', pem, { ahora: AHORA })).toEqual({
      ok: false,
      rechazo: { status: 401, tipo: 'token_malformado' },
    })
    expect(await verificarToken('aaa.bbb.ccc', pem, { ahora: AHORA })).toEqual({
      ok: false,
      rechazo: { status: 401, tipo: 'token_malformado' },
    })
  })

  it('nbf 4 min en el futuro → dentro de tolerancia (±5 min)', async () => {
    const jwt = await firmar(payloadBase(), privada, { nbfOffsetSeg: 4 * min })
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r.ok).toBe(true)
  })

  it('nbf 6 min en el futuro → expirado, con ReentryURL para el redirect', async () => {
    const jwt = await firmar(payloadBase(), privada, { nbfOffsetSeg: 6 * min })
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r).toEqual({
      ok: false,
      rechazo: { status: 401, tipo: 'expirado', reentryUrl: 'https://lanzadera.example/reentry' },
    })
  })

  it('exp 4 min en el pasado → dentro de tolerancia', async () => {
    const jwt = await firmar(payloadBase(), privada, { expOffsetSeg: -4 * min })
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r.ok).toBe(true)
  })

  it('exp 6 min en el pasado → expirado', async () => {
    const payload = payloadBase()
    delete payload['ReentryURL']
    const jwt = await firmar(payload, privada, { expOffsetSeg: -6 * min })
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r).toEqual({
      ok: false,
      rechazo: { status: 401, tipo: 'expirado', reentryUrl: null },
    })
  })

  it('sin atribución bajo la raíz → 403 sin_atribucion_ftg', async () => {
    const payload = payloadBase()
    payload['Rol'] = JSON.stringify({
      Atribucion: [{ AtribucionPath: '.OtraApp.Modulo.', Propiedad: '.X.' }],
      Alcance: rolBase()['Alcance'],
    })
    const jwt = await firmar(payload, privada)
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r).toEqual({ ok: false, rechazo: { status: 403, tipo: 'sin_atribucion_ftg' } })
  })

  it('token centinela sin empresa (EmpKey=0) → 403 sin_empresa', async () => {
    const payload = payloadBase()
    payload['Rol'] = JSON.stringify({
      Atribucion: [{ AtribucionPath: '.Ftg.', Propiedad: '.X.C.R.U.D.' }],
      Alcance: [
        {
          AlcancePath: '.*Empresa.0.000000000. . . .',
          AlcanceTemplatePath: '.*Empresa.EmpresaKey.EmpresaRut.EmpresaNombre.',
        },
      ],
    })
    const jwt = await firmar(payload, privada)
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r).toEqual({ ok: false, rechazo: { status: 403, tipo: 'sin_empresa' } })
  })

  it('sucursal en template + nombre con puntos → 403 sucursal_con_desborde', async () => {
    const payload = payloadBase()
    payload['Rol'] = JSON.stringify({
      Atribucion: [{ AtribucionPath: '.Ftg.', Propiedad: '.X.C.R.U.D.' }],
      Alcance: [
        {
          AlcancePath: '.*Empresa.977.921760000.ACEROS AZA S.A..1.Casa Matriz.',
          AlcanceTemplatePath: '.*Empresa.EmpresaKey.EmpresaRut.EmpresaNombre.SucursalIdL.SucursalNombre.',
        },
      ],
    })
    const jwt = await firmar(payload, privada)
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r).toEqual({ ok: false, rechazo: { status: 403, tipo: 'sucursal_con_desborde' } })
  })

  // Regresión: el token real trae `Rol` como JSON serializado. El cast directo
  // a objeto lo dejaba en undefined y rechazaba con sin_atribucion_ftg un token
  // que traía las cuatro atribuciones .Ftg.* con .X.C.R.U.D.
  it('Rol serializado con atribuciones .Ftg.* anidadas → sesión válida', async () => {
    const payload = payloadBase()
    payload['Rol'] = JSON.stringify({
      RolName: 'AdminGuias',
      RolKey: 93,
      Atribucion: [
        { AtribucionPath: '.Ftg.FtgOpe.FtgOpeFac.', Propiedad: '.X.C.R.U.D.' },
        { AtribucionPath: '.Ftg.FtgOpe.', Propiedad: '.X.C.R.U.D.' },
        { AtribucionPath: '.Ftg.FtgCfg.', Propiedad: '.X.C.R.U.D.' },
        { AtribucionPath: '.Ftg.', Propiedad: '.X.C.R.U.D.' },
      ],
      Alcance: rolBase()['Alcance'],
    })
    const jwt = await firmar(payload, privada)
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r.ok).toBe(true)
    if (r.ok) {
      expect(r.sesion.atribuciones).toHaveLength(4)
      expect(r.sesion.empresa).toEqual({
        key: '977',
        rut: '921760000',
        nombre: 'ACEROS AZA S.A.',
      })
    }
  })

  it('Rol como objeto anidado (no serializado) también se acepta', async () => {
    const payload = payloadBase()
    payload['Rol'] = rolBase()
    const jwt = await firmar(payload, privada)
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r.ok).toBe(true)
  })

  it('Rol ilegible (string no-JSON) → 403 sin_atribucion_ftg, no crash', async () => {
    const payload = payloadBase()
    payload['Rol'] = 'esto-no-es-json'
    const jwt = await firmar(payload, privada)
    const r = await verificarToken(jwt, pem, { ahora: AHORA })
    expect(r).toEqual({ ok: false, rechazo: { status: 403, tipo: 'sin_atribucion_ftg' } })
  })

  it('clave pública no importable → 503 clave_publica_invalida', async () => {
    const jwt = await firmar(payloadBase(), privada)
    const r = await verificarToken(jwt, '-----BEGIN PUBLIC KEY-----\nZGF0YS1jb3JydXB0bw==\n-----END PUBLIC KEY-----', { ahora: AHORA })
    expect(r).toEqual({ ok: false, rechazo: { status: 503, tipo: 'clave_publica_invalida' } })
  })

  it('tolerancia configurable: con 60s el nbf a 4 min en el futuro expira', async () => {
    const jwt = await firmar(payloadBase(), privada, { nbfOffsetSeg: 4 * min })
    const r = await verificarToken(jwt, pem, { ahora: AHORA, toleranciaSegundos: 60 })
    expect(r.ok).toBe(false)
    if (!r.ok) expect(r.rechazo.tipo).toBe('expirado')
  })
})
