import { describe, it, expect } from 'vitest'
import { tieneAccesoFtg, puedeRealizar } from '../src/atribuciones.js'
import type { Atribucion } from '../src/tipos.js'

const atr = (path: string, propiedad: string): Atribucion => ({ path, propiedad })

describe('tieneAccesoFtg (puerta gruesa)', () => {
  it('sin atribuciones no hay acceso', () => {
    expect(tieneAccesoFtg([])).toBe(false)
  })

  it('atribución en la raíz pelada da acceso (pertenencia)', () => {
    expect(tieneAccesoFtg([atr('.Ftg.', '.R.')])).toBe(true)
  })

  it('atribución bajo la raíz da acceso', () => {
    expect(tieneAccesoFtg([atr('.Ftg.Facturacion.', '.R.')])).toBe(true)
  })

  it('atribución fuera de la raíz no da acceso', () => {
    expect(tieneAccesoFtg([atr('.Otra.Cosa.', '.R.')])).toBe(false)
  })

  it('no confunde prefijos de segmento (.Ftg2. no es .Ftg.)', () => {
    expect(tieneAccesoFtg([atr('.Ftg2.Modulo.', '.R.')])).toBe(false)
  })

  it('respeta raíz configurable', () => {
    expect(tieneAccesoFtg([atr('.Raiz.Nodo.', '.R.')], '.Raiz.')).toBe(true)
    expect(tieneAccesoFtg([atr('.Ftg.Nodo.', '.R.')], '.Raiz.')).toBe(false)
  })
})

describe('puedeRealizar (matching RWXD)', () => {
  it('match exacto otorga la letra', () => {
    expect(puedeRealizar([atr('.Ftg.Facturacion.', '.R.')], '.Ftg.Facturacion.', 'R')).toBe(true)
  })

  it('match árbol: atribución cubre descendientes', () => {
    expect(puedeRealizar([atr('.Ftg.', '.X.')], '.Ftg.', 'X')).toBe(true)
    expect(puedeRealizar([atr('.Ftg.Facturacion.', '.C.')], '.Ftg.Facturacion.Emitir.', 'C')).toBe(true)
  })

  it('letras son independientes: R sin X es válido', () => {
    const atribs = [atr('.Ftg.Facturacion.', '.R.')]
    expect(puedeRealizar(atribs, '.Ftg.Facturacion.', 'R')).toBe(true)
    expect(puedeRealizar(atribs, '.Ftg.Facturacion.', 'X')).toBe(false)
  })

  it('acción con varias letras exige AND', () => {
    const atribs = [atr('.Ftg.Facturacion.', '.R.U.')]
    expect(puedeRealizar(atribs, '.Ftg.Facturacion.', 'RU')).toBe(true)
    expect(puedeRealizar(atribs, '.Ftg.Facturacion.', 'RUD')).toBe(false)
  })

  it('el AND puede satisfacerse con atribuciones distintas por letra', () => {
    const atribs = [atr('.Ftg.Facturacion.', '.R.'), atr('.Ftg.Facturacion.', '.U.')]
    expect(puedeRealizar(atribs, '.Ftg.Facturacion.', 'RU')).toBe(true)
  })

  it('contención delimitada: propiedad sin puntos no matchea', () => {
    expect(puedeRealizar([atr('.Ftg.Facturacion.', 'XCRUD')], '.Ftg.Facturacion.', 'R')).toBe(false)
  })

  it('R con match rama: atribución descendiente otorga lectura de ancestros', () => {
    const atribs = [atr('.Ftg.Facturacion.Emitir.Guias.', '.R.')]
    expect(puedeRealizar(atribs, '.Ftg.Facturacion.', 'R')).toBe(true)
    expect(puedeRealizar(atribs, '.Ftg.', 'R')).toBe(true)
  })

  it('C/U/D/X no tienen match rama', () => {
    const atribs = [atr('.Ftg.Facturacion.Emitir.', '.C.U.D.X.')]
    for (const letra of ['C', 'U', 'D', 'X']) {
      expect(puedeRealizar(atribs, '.Ftg.Facturacion.', letra)).toBe(false)
    }
  })

  it('la raíz da entrada, no autoridad: .Ftg. pelada no concede hijos', () => {
    const atribs = [atr('.Ftg.', '.X.C.R.U.D.')]
    expect(tieneAccesoFtg(atribs)).toBe(true)
    expect(puedeRealizar(atribs, '.Ftg.', 'R')).toBe(true)
    expect(puedeRealizar(atribs, '.Ftg.Facturacion.', 'R')).toBe(false)
    expect(puedeRealizar(atribs, '.Ftg.Facturacion.', 'X')).toBe(false)
  })

  it('paths sin punto final se normalizan', () => {
    expect(puedeRealizar([atr('.Ftg.Facturacion', '.R.')], '.Ftg.Facturacion.Emitir', 'R')).toBe(true)
  })

  it('respeta raíz configurable para la exclusión de la raíz pelada', () => {
    const atribs = [atr('.Raiz.', '.R.')]
    expect(puedeRealizar(atribs, '.Raiz.Hijo.', 'R', '.Raiz.')).toBe(false)
    // con la raíz default .Ftg., .Raiz. no es raíz pelada y sí concede hijos
    expect(puedeRealizar(atribs, '.Raiz.Hijo.', 'R')).toBe(true)
  })
})
