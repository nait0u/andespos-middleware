import { describe, it, expect } from 'vitest'
import { parsearAlcances } from '../src/alcances.js'

const alc = (AlcancePath: string, AlcanceTemplatePath: string) => ({ AlcancePath, AlcanceTemplatePath })

const TEMPLATE_EMPRESA = '.*Empresa.EmpresaKey.EmpresaRut.EmpresaNombre.'
const TEMPLATE_EMPRESA_SUC = '.*Empresa.EmpresaKey.EmpresaRut.EmpresaNombre.SucursalIdL.SucursalNombre.'

describe('parsearAlcances', () => {
  it('alcance Empresa bien formado extrae la empresa escalar y no va a la colección', () => {
    const r = parsearAlcances([alc('.*Empresa.12345.96789010.MINERIA EJEMPLO.', TEMPLATE_EMPRESA)])
    expect(r.empresa).toEqual({ key: '12345', rut: '96789010', nombre: 'MINERIA EJEMPLO' })
    expect(r.alcances).toEqual([])
    expect(r.problemas).toEqual([])
    expect(r.sinEmpresa).toBe(false)
    expect(r.sucursalConDesborde).toBe(false)
  })

  it('nombre con puntos sin sucursal: tail greedy recupera key/rut y degrada con desborde_puntos', () => {
    const r = parsearAlcances([alc('.*Empresa.6789.76123456.ACEROS AZA S.A..', TEMPLATE_EMPRESA)])
    expect(r.empresa).toEqual({ key: '6789', rut: '76123456', nombre: 'ACEROS AZA S.A.' })
    expect(r.problemas).toHaveLength(1)
    expect(r.problemas[0]!.tipo).toBe('desborde_puntos')
    expect(r.sucursalConDesborde).toBe(false)
  })

  it('token centinela sin empresa (EmpKey = 0): flag sin_empresa', () => {
    const r = parsearAlcances([alc('.*Empresa.0.000000000. . . .', TEMPLATE_EMPRESA)])
    expect(r.sinEmpresa).toBe(true)
    expect(r.empresa).toBeNull()
    // el centinela es una forma esperada: no se reporta desborde por sus espacios
    expect(r.problemas).toEqual([])
  })

  it('sucursal fantasma (segmentos de un espacio) degrada con sucursal_fantasma', () => {
    const r = parsearAlcances([alc('.*Empresa.2222.96789010.EMPRESA SUR. . .', TEMPLATE_EMPRESA_SUC)])
    expect(r.empresa).toEqual({ key: '2222', rut: '96789010', nombre: 'EMPRESA SUR' })
    expect(r.problemas.map((p) => p.tipo)).toContain('sucursal_fantasma')
  })

  it('sucursal real no genera problemas', () => {
    const r = parsearAlcances([alc('.*Empresa.2222.96789010.EMPRESA SUR.5.CASA MATRIZ.', TEMPLATE_EMPRESA_SUC)])
    expect(r.problemas).toEqual([])
    expect(r.empresa!.key).toBe('2222')
  })

  it('template con sucursal + nombre con puntos: flag sucursalConDesborde', () => {
    const r = parsearAlcances([alc('.*Empresa.3333.96789010.ACEROS AZA S.A..5.CASA MATRIZ.', TEMPLATE_EMPRESA_SUC)])
    expect(r.sucursalConDesborde).toBe(true)
  })

  it('alcance corto con etiqueta repetida (caso .Ambiente. real)', () => {
    const r = parsearAlcances([
      alc('.*Empresa.12345.96789010.MINERIA EJEMPLO.', TEMPLATE_EMPRESA),
      alc('.Ambiente.AmbientesEnternet.certificacionypruebas.', '.Ambiente.TipoAmbiente.TipoAmbiente.AmbienteNombre.'),
    ])
    const tipos = r.problemas.map((p) => p.tipo)
    expect(tipos).toContain('alcance_corto')
    expect(tipos).toContain('etiqueta_repetida')
    // el alcance no-Empresa se conserva crudo en la colección
    expect(r.alcances).toEqual([
      { path: '.Ambiente.AmbientesEnternet.certificacionypruebas.', templatePath: '.Ambiente.TipoAmbiente.TipoAmbiente.AmbienteNombre.' },
    ])
    // la empresa sigue extrayéndose del alcance Empresa sano
    expect(r.empresa!.key).toBe('12345')
  })

  it('conjunto vacío no es parámetro ausente: [] no es centinela', () => {
    const r = parsearAlcances([])
    expect(r.sinEmpresa).toBe(false)
    expect(r.empresa).toBeNull()
    expect(r.alcances).toEqual([])
  })

  it('raw ausente o con forma inválida se tolera como conjunto vacío', () => {
    for (const raw of [undefined, null, {}, 'texto', [null, 42, { AlcancePath: 1 }]]) {
      const r = parsearAlcances(raw)
      expect(r.alcances).toEqual([])
      expect(r.sinEmpresa).toBe(false)
    }
  })
})
